const Database = require('./initalizeDatabase');
const App = require('./initializeApp')

module.exports = {
    Database,
    App
}