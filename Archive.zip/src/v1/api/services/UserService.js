const { User, sequelize, EventList } = require('../../../data/models/index');
const { QueryTypes } = require('sequelize');
const promise = require('bluebird')
const ejs = require('ejs')
const path = require('path')
const helper = require('../../../utills/helper')
const axios = require('axios');
const qs = require('qs');
const { access } = require('fs')
const moment = require('moment')

const { google } = require('googleapis');
const { start } = require('repl')
const event_list = require('../../../data/models/event_list')

const oauth2Client = new google.auth.OAuth2(
  process.env.CLIENT_ID,
  process.env.CLIENT_SECRET,
  'http://localhost:3000'
);

class UserService {
  async calenderList(body) {
    // return new Promise(async (resolve, reject) => {
    try {
      let {
        code,
        type,
        mail
      } = body, access_token;

      let user = await User.findOne({
        attributes: ['token'],
        where: {
          mail: mail,
          type: type
        }
      });
      var calendarList = [];
      // google calendar
      if (body.type == 1) {
        calendarList = this.googleCalendarList(body)
      }
      // console.log("user", user);

      return calendarList;
    } catch (error) {
      console.log("calenderList Service Error=====>>>>", error)
      return promise.reject(error)
    }
  }

  async googleCalendarList(body) {
    try {
      let {
        code,
        type,
        mail
      } = body, access_token;

      var options = {
        'method': 'get',
        'url': 'https://www.googleapis.com/calendar/v3/users/me/calendarList',
        'headers': {
          'Authorization': 'Bearer ' + code
        }
      };
      let calendarList = await axios(options);

      return calendarList.data || [];

    } catch (error) {
      return Promise.reject(error)
    }
  }

  async eventList(body) {
    try {
      let {
        calendar_id,
        code,
        mail,
        type
      } = body, access_token, data = [];

      let user = await User.findOne({
        attributes: ['token'],
        where: {
          mail: mail,
          type: type
        }
      });

      // unneccesary code
      /* var data = qs.stringify({
        'client_id': process.env.CLIENT_ID,
        'client_secret': process.env.CLIENT_SECRET,
        'refresh_token': user.token,
        'grant_type': 'refresh_token'
      });
      var config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://accounts.google.com/o/oauth2/token',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: data
      };
      let calendar = await axios(config);
      console.log("calendar=====>>>>>", calendar.data)
      if (calendar.status == 200)
        access_token = calendar.data.access_token */


      // useful code  
      /* var options2 = {
        'method': 'get',
        'url': `https://www.googleapis.com/calendar/v3/calendars/${calendar_id}/events`,
        'headers': {
          'Authorization': 'Bearer ' + code
        }
      };
      let eventList = await axios(options2); */
      let event = [
        {
          "kind": "calendar#event",
          "etag": "\"3214362042930000\"",
          "id": "6hh3cd1gcgq34bb3chgj4b9k60o36b9p75h3ebb56gs3gc1i6grmce1hcg",
          "status": "confirmed",
          "htmlLink": "https://www.google.com/calendar/event?eid=NmhoM2NkMWdjZ3EzNGJiM2NoZ2o0YjlrNjBvMzZiOXA3NWgzZWJiNTZnczNnYzFpNmdybWNlMWhjZyB0cmlzdGF0ZS50ZXN0aW5nMzIxQG0",
          "created": "2020-12-05T15:10:21.000Z",
          "updated": "2020-12-05T15:10:21.465Z",
          "summary": "Vi Recharge due for 9638226957",
          "creator": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "organizer": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "start": {
            "dateTime": "2020-12-13T00:00:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "end": {
            "dateTime": "2020-12-13T23:59:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "iCalUID": "6hh3cd1gcgq34bb3chgj4b9k60o36b9p75h3ebb56gs3gc1i6grmce1hcg@google.com",
          "sequence": 0,
          "reminders": {
            "useDefault": true
          },
          "eventType": "default"
        },
        {
          "kind": "calendar#event",
          "etag": "\"3356337638224000\"",
          "id": "1aoc1vppeav385ub4ulj39rftd",
          "status": "confirmed",
          "htmlLink": "https://www.google.com/calendar/event?eid=MWFvYzF2cHBlYXYzODV1YjR1bGozOXJmdGQgdHJpc3RhdGUudGVzdGluZzMyMUBt",
          "created": "2023-03-07T06:00:19.000Z",
          "updated": "2023-03-07T06:00:19.112Z",
          "summary": "Demo1",
          "creator": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "organizer": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "start": {
            "dateTime": "2023-03-13T08:30:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "end": {
            "dateTime": "2023-03-13T14:15:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "iCalUID": "1aoc1vppeav385ub4ulj39rftd@google.com",
          "sequence": 0,
          "reminders": {
            "useDefault": true
          },
          "eventType": "default"
        },
        {
          "kind": "calendar#event",
          "etag": "\"3356337647098000\"",
          "id": "20ctnlbpgkea075rtv5quciun7",
          "status": "confirmed",
          "htmlLink": "https://www.google.com/calendar/event?eid=MjBjdG5sYnBna2VhMDc1cnR2NXF1Y2l1bjcgdHJpc3RhdGUudGVzdGluZzMyMUBt",
          "created": "2023-03-07T06:00:23.000Z",
          "updated": "2023-03-07T06:00:23.549Z",
          "summary": "demo2",
          "creator": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "organizer": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "start": {
            "dateTime": "2023-03-15T12:45:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "end": {
            "dateTime": "2023-03-15T19:00:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "iCalUID": "20ctnlbpgkea075rtv5quciun7@google.com",
          "sequence": 0,
          "reminders": {
            "useDefault": true
          },
          "eventType": "default"
        },
        {
          "kind": "calendar#event",
          "etag": "\"3356337655222000\"",
          "id": "7t3j6uouqd6ec92omf48o5179o",
          "status": "confirmed",
          "htmlLink": "https://www.google.com/calendar/event?eid=N3QzajZ1b3VxZDZlYzkyb21mNDhvNTE3OW8gdHJpc3RhdGUudGVzdGluZzMyMUBt",
          "created": "2023-03-07T06:00:27.000Z",
          "updated": "2023-03-07T06:00:27.611Z",
          "summary": "demo3",
          "creator": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "organizer": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "start": {
            "dateTime": "2023-03-17T08:30:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "end": {
            "dateTime": "2023-03-17T13:00:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "iCalUID": "7t3j6uouqd6ec92omf48o5179o@google.com",
          "sequence": 0,
          "reminders": {
            "useDefault": true
          },
          "eventType": "default"
        },
        {
          "kind": "calendar#event",
          "etag": "\"3356337663800000\"",
          "id": "5h6cko5ch3sg2dmh67r5lcv15h",
          "status": "confirmed",
          "htmlLink": "https://www.google.com/calendar/event?eid=NWg2Y2tvNWNoM3NnMmRtaDY3cjVsY3YxNWggdHJpc3RhdGUudGVzdGluZzMyMUBt",
          "created": "2023-03-07T06:00:31.000Z",
          "updated": "2023-03-07T06:00:31.900Z",
          "summary": "demo4",
          "creator": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "organizer": {
            "email": "tristate.testing321@gmail.com",
            "self": true
          },
          "start": {
            "dateTime": "2023-03-13T17:00:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "end": {
            "dateTime": "2023-03-13T20:30:00+05:30",
            "timeZone": "Asia/Kolkata"
          },
          "iCalUID": "5h6cko5ch3sg2dmh67r5lcv15h@google.com",
          "sequence": 0,
          "reminders": {
            "useDefault": true
          },
          "eventType": "default"
        }
      ]

      let list = [];
      const loopForHistory1 = async _ => {
        let promises2 = event.map(async (x) => {
          console.log(x.id)
          data.push({
            mail_id: mail,
            event_id: x.id,
            start_time: x.start.dateTime,
            end_time: x.end.dateTime,
            summary: x.summary,
            calendar_id: calendar_id,
            type: type
          })

          let arr = await sequelize.query(`select * from event_lists where mail_id = '${mail}' and event_id = '${x.id}'`, { type: QueryTypes.SELECT });
          if (arr.length == 0) {
            list.push({
              mail_id: mail,
              event_id: x.id,
              start_time: x.start.dateTime,
              end_time: x.end.dateTime,
              summary: x.summary,
              calendar_id: calendar_id,
              type: type
            })
          }
        })
        await Promise.all(promises2)
      }
      await loopForHistory1()


      let eventList = []
      console.log("list=====>", list)
      if (list.length > 0)
        eventList = await EventList.bulkCreate(list)
      return data;
    } catch (error) {
      return Promise.reject(error)
    }
  }
}
module.exports = new UserService()